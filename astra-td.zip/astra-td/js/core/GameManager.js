/**
 * ASTRA: Aether Guardians — Game Manager
 * Finite State Machine for game state management
 */
import { GameLoop } from './GameLoop.js';
import { GridManager } from './GridManager.js';
import { Camera } from './Camera.js';
import { InputManager } from './InputManager.js';
import { AetherResourceSystem } from './AetherResourceSystem.js';
import { WaveManager } from './WaveManager.js';
import { HUDController } from '../ui/HUDController.js';
import { UnitInfoPanel } from '../ui/UnitInfoPanel.js';
import { MainMenu } from '../ui/MainMenu.js';
import { StageSelect } from '../ui/StageSelect.js';
import { ResultScreen } from '../ui/ResultScreen.js';
import { DialogueSystem } from '../ui/DialogueSystem.js';
import { SceneTransition } from '../ui/SceneTransition.js';
import { AssetLoader } from '../utils/AssetLoader.js';
import { SaveManager } from '../utils/SaveManager.js';
import { SoundManager } from '../utils/SoundManager.js';
import { ObjectPool } from '../utils/ObjectPool.js';
import { Projectile } from '../entities/Projectile.js';
import { UNIT_DATA } from '../data/unitData.js';
import { ENEMY_DATA } from '../data/enemyData.js';
import { STAGE_DATA } from '../data/stageData.js';
import { createUnit } from '../entities/units/UnitFactory.js';
import { createEnemy } from '../entities/enemies/EnemyFactory.js';

/**
 * Game states enum
 */
export const GameState = {
  LOADING: 'LOADING',
  MENU: 'MENU',
  STAGE_SELECT: 'STAGE_SELECT',
  PRE_BATTLE: 'PRE_BATTLE',   // Dialogue/cutscene before battle
  BATTLE: 'BATTLE',
  PAUSE: 'PAUSE',
  POST_BATTLE: 'POST_BATTLE', // Dialogue after battle
  RESULT: 'RESULT',
};

export class GameManager {
  constructor() {
    // State
    this.state = GameState.LOADING;
    this.previousState = null;

    // Canvas setup
    this.bgCanvas = document.getElementById('bg-canvas');
    this.entityCanvas = document.getElementById('entity-canvas');
    this.fxCanvas = document.getElementById('fx-canvas');
    this.bgCtx = this.bgCanvas.getContext('2d');
    this.entityCtx = this.entityCanvas.getContext('2d');
    this.fxCtx = this.fxCanvas.getContext('2d');

    // Game dimensions
    this.gameWidth = 1280;
    this.gameHeight = 720;

    // Core systems
    this.gameLoop = new GameLoop();
    this.camera = new Camera(this.gameWidth, this.gameHeight);
    this.gridManager = null;
    this.inputManager = null;
    this.resourceSystem = null;
    this.waveManager = null;
    this.assetLoader = new AssetLoader();
    this.saveManager = new SaveManager();
    this.soundManager = new SoundManager();

    // UI systems
    this.hud = null;
    this.unitInfoPanel = null;
    this.mainMenu = null;
    this.stageSelect = null;
    this.resultScreen = null;
    this.dialogueSystem = null;
    this.sceneTransition = null;

    // Game entities
    this.units = [];
    this.enemies = [];
    this.projectiles = [];
    this.floatingTexts = [];

    // Object pools
    this.projectilePool = new ObjectPool(() => new Projectile(), 50);

    // Battle state
    this.currentStageId = null;
    this.currentStageData = null;
    this.coreHP = 20;
    this.coreMaxHP = 20;
    this.selectedUnitType = null;
    this.selectedPlacedUnit = null;
    this.isWaveActive = false;

    // Player data
    this.playerData = this.saveManager.load();

    this._setupCanvases();
  }

  /**
   * Initialize and start the game
   */
  async init() {
    console.log('[ASTRA] Initializing game...');

    // Show loading screen
    this._showScreen('loading-screen');

    // Load assets
    await this._loadAssets();

    // Initialize UI systems
    this._initUI();

    // Start game loop
    this.gameLoop.start(
      (dt) => this.update(dt),
      (interp) => this.render(interp)
    );

    // Transition to main menu
    this.setState(GameState.MENU);
    console.log('[ASTRA] Game initialized successfully!');
  }

  /**
   * Setup canvas dimensions and scaling
   */
  _setupCanvases() {
    const canvases = [this.bgCanvas, this.entityCanvas, this.fxCanvas];
    canvases.forEach(canvas => {
      canvas.width = this.gameWidth;
      canvas.height = this.gameHeight;
    });
    this._handleResize();
    window.addEventListener('resize', () => this._handleResize());
  }

  _handleResize() {
    const windowW = window.innerWidth;
    const windowH = window.innerHeight;
    const scale = Math.min(windowW / this.gameWidth, windowH / this.gameHeight);
    const scaledW = Math.floor(this.gameWidth * scale);
    const scaledH = Math.floor(this.gameHeight * scale);

    const canvases = [this.bgCanvas, this.entityCanvas, this.fxCanvas];
    canvases.forEach(canvas => {
      canvas.style.width = `${scaledW}px`;
      canvas.style.height = `${scaledH}px`;
    });

    // Store scale for input coordinate conversion
    this.displayScale = scale;
    this.displayOffsetX = (windowW - scaledW) / 2;
    this.displayOffsetY = (windowH - scaledH) / 2;
  }

  /**
   * Load game assets
   */
  async _loadAssets() {
    const loadingBar = document.getElementById('loading-bar');
    const loadingText = document.getElementById('loading-text');

    // Create loading particles
    this._createLoadingParticles();

    // Simulate asset loading phases
    const phases = [
      { text: 'Loading core systems...', progress: 20 },
      { text: 'Loading unit data...', progress: 40 },
      { text: 'Loading enemy data...', progress: 60 },
      { text: 'Loading stage data...', progress: 80 },
      { text: 'Initializing Aether...', progress: 100 },
    ];

    for (const phase of phases) {
      loadingText.textContent = phase.text;
      loadingBar.style.width = `${phase.progress}%`;
      await this._delay(400);
    }

    await this._delay(500);
  }

  _createLoadingParticles() {
    const container = document.getElementById('loading-particles');
    if (!container) return;
    for (let i = 0; i < 30; i++) {
      const particle = document.createElement('div');
      particle.className = 'loading-particle';
      particle.style.left = `${Math.random() * 100}%`;
      particle.style.animationDuration = `${3 + Math.random() * 5}s`;
      particle.style.animationDelay = `${Math.random() * 3}s`;
      particle.style.opacity = `${0.3 + Math.random() * 0.7}`;
      const size = 2 + Math.random() * 4;
      particle.style.width = `${size}px`;
      particle.style.height = `${size}px`;

      // Randomize color between blue and purple
      const hue = 200 + Math.random() * 80;
      particle.style.background = `hsl(${hue}, 80%, 60%)`;
      particle.style.boxShadow = `0 0 ${size * 2}px hsl(${hue}, 80%, 60%)`;

      container.appendChild(particle);
    }
  }

  /**
   * Initialize UI systems
   */
  _initUI() {
    this.sceneTransition = new SceneTransition();
    this.mainMenu = new MainMenu(this);
    this.stageSelect = new StageSelect(this);
    this.hud = new HUDController(this);
    this.unitInfoPanel = new UnitInfoPanel(this);
    this.resultScreen = new ResultScreen(this);
    this.dialogueSystem = new DialogueSystem(this);
  }

  /**
   * Change game state with transition
   */
  async setState(newState) {
    const oldState = this.state;
    this.previousState = oldState;
    this.state = newState;

    console.log(`[ASTRA] State: ${oldState} → ${newState}`);

    // Handle state exit
    this._onStateExit(oldState);

    // Handle state enter
    this._onStateEnter(newState);
  }

  _onStateExit(state) {
    switch (state) {
      case GameState.LOADING:
        this._hideScreen('loading-screen');
        break;
      case GameState.MENU:
        this._hideScreen('main-menu-screen');
        break;
      case GameState.STAGE_SELECT:
        this._hideScreen('stage-select-screen');
        break;
      case GameState.BATTLE:
      case GameState.PAUSE:
        break;
      case GameState.RESULT:
        this._hideScreen('result-screen');
        break;
    }
  }

  _onStateEnter(state) {
    switch (state) {
      case GameState.MENU:
        this._showScreen('main-menu-screen');
        this._hideScreen('game-container');
        this.mainMenu.show();
        break;

      case GameState.STAGE_SELECT:
        this._showScreen('stage-select-screen');
        this.stageSelect.show();
        break;

      case GameState.PRE_BATTLE:
        this._startBattle();
        break;

      case GameState.BATTLE:
        this._showScreen('game-container');
        if (this.inputManager) {
          this.inputManager.enable();
        }
        break;

      case GameState.PAUSE:
        document.getElementById('pause-overlay').classList.remove('hidden');
        break;

      case GameState.RESULT:
        this._showResultScreen();
        break;
    }
  }

  /**
   * Start a battle stage
   */
  _startBattle() {
    const stageData = STAGE_DATA[this.currentStageId];
    if (!stageData) {
      console.error(`[ASTRA] Stage not found: ${this.currentStageId}`);
      this.setState(GameState.STAGE_SELECT);
      return;
    }

    this.currentStageData = stageData;

    // Reset battle state
    this.units = [];
    this.enemies = [];
    this.projectiles = [];
    this.floatingTexts = [];
    this.coreHP = stageData.coreHP || 20;
    this.coreMaxHP = this.coreHP;
    this.selectedUnitType = null;
    this.selectedPlacedUnit = null;
    this.isWaveActive = false;

    // Initialize grid
    this.gridManager = new GridManager(stageData.grid, stageData.tileSize || 64);

    // Initialize resource system
    this.resourceSystem = new AetherResourceSystem(stageData.startingAether || 200);

    // Initialize wave manager
    this.waveManager = new WaveManager(stageData.waves, this);

    // Initialize input
    this.inputManager = new InputManager(this);

    // Update HUD
    this.hud.init();

    // Show game container
    this._showScreen('game-container');

    // Render background grid (only once)
    this._renderBackground();

    // Enter battle state
    this.setState(GameState.BATTLE);
  }

  /**
   * Select a stage and start battle
   */
  selectStage(stageId) {
    this.currentStageId = stageId;
    this.setState(GameState.PRE_BATTLE);
  }

  /**
   * Main update loop — called at fixed timestep
   */
  update(dt) {
    if (this.state !== GameState.BATTLE) return;

    // Update resource system (passive Aether generation)
    if (this.isWaveActive) {
      this.resourceSystem.update(dt);
    }

    // Update wave manager
    if (this.isWaveActive) {
      this.waveManager.update(dt);
    }

    // Update units
    for (let i = this.units.length - 1; i >= 0; i--) {
      const unit = this.units[i];
      unit.update(dt, this.enemies, this);
      if (unit.isDead) {
        this.units.splice(i, 1);
      }
    }

    // Update enemies
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const enemy = this.enemies[i];
      enemy.update(dt, this);

      if (enemy.isDead) {
        // Grant rewards
        this.resourceSystem.addAether(enemy.rewardAether);
        this.enemies.splice(i, 1);
      } else if (enemy.reachedEnd) {
        // Damage core
        this.coreHP -= enemy.damageToCore;
        this.enemies.splice(i, 1);
        this.hud.onCoreHit();

        if (this.coreHP <= 0) {
          this.coreHP = 0;
          this._onDefeat();
          return;
        }
      }
    }

    // Update projectiles
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const proj = this.projectiles[i];
      proj.update(dt);
      if (proj.isDead) {
        this.projectilePool.release(proj);
        this.projectiles.splice(i, 1);
      }
    }

    // Update floating texts
    for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
      this.floatingTexts[i].life -= dt;
      this.floatingTexts[i].y -= 30 * dt;
      if (this.floatingTexts[i].life <= 0) {
        this.floatingTexts.splice(i, 1);
      }
    }

    // Update HUD
    this.hud.update();

    // Check victory
    if (this.waveManager.isComplete() && this.enemies.length === 0 && this.isWaveActive) {
      this._onVictory();
    }
  }

  /**
   * Main render loop — called every frame
   */
  render(interpolation) {
    if (this.state !== GameState.BATTLE && this.state !== GameState.PAUSE) return;

    const ctx = this.entityCtx;
    ctx.clearRect(0, 0, this.gameWidth, this.gameHeight);

    // Apply camera transform
    ctx.save();
    this.camera.applyTransform(ctx);

    // Render grid highlight (hovered tile)
    if (this.inputManager) {
      this.gridManager.renderHighlight(ctx, this.inputManager.hoveredTile);
    }

    // Render placement indicators
    if (this.selectedUnitType && this.inputManager && this.inputManager.hoveredTile) {
      this.gridManager.renderPlacementIndicator(
        ctx,
        this.inputManager.hoveredTile,
        this.gridManager.canPlace(this.inputManager.hoveredTile.col, this.inputManager.hoveredTile.row)
      );
    }

    // Render enemies (sorted by Y for depth)
    const sortedEnemies = [...this.enemies].sort((a, b) => a.y - b.y);
    for (const enemy of sortedEnemies) {
      enemy.render(ctx, interpolation);
    }

    // Render units (sorted by Y for depth)
    const sortedUnits = [...this.units].sort((a, b) => a.y - b.y);
    for (const unit of sortedUnits) {
      unit.render(ctx, interpolation);
      // Highlight selected unit
      if (unit === this.selectedPlacedUnit) {
        unit.renderSelection(ctx);
        unit.renderRange(ctx);
      }
    }

    // Render projectiles
    for (const proj of this.projectiles) {
      proj.render(ctx, interpolation);
    }

    ctx.restore();

    // Render FX layer (floating texts, particles)
    const fxCtx = this.fxCtx;
    fxCtx.clearRect(0, 0, this.gameWidth, this.gameHeight);

    fxCtx.save();
    this.camera.applyTransform(fxCtx);

    for (const ft of this.floatingTexts) {
      const alpha = Math.max(0, ft.life / ft.maxLife);
      fxCtx.globalAlpha = alpha;
      fxCtx.font = `bold ${ft.size || 16}px Outfit`;
      fxCtx.fillStyle = ft.color || '#ff4444';
      fxCtx.textAlign = 'center';
      fxCtx.fillText(ft.text, ft.x, ft.y);
    }
    fxCtx.globalAlpha = 1;
    fxCtx.restore();
  }

  /**
   * Render static background (isometric grid)
   */
  _renderBackground() {
    const ctx = this.bgCtx;
    ctx.clearRect(0, 0, this.gameWidth, this.gameHeight);

    // Dark background
    ctx.fillStyle = '#0a0a12';
    ctx.fillRect(0, 0, this.gameWidth, this.gameHeight);

    ctx.save();
    this.camera.applyTransform(ctx);

    // Render grid tiles
    this.gridManager.renderGrid(ctx);

    // Render path indicators
    this.gridManager.renderPaths(ctx);

    // Render core/crystal position
    if (this.currentStageData && this.currentStageData.corePosition) {
      this.gridManager.renderCore(ctx, this.currentStageData.corePosition);
    }

    ctx.restore();
  }

  /**
   * Place a unit on the grid
   */
  placeUnit(col, row, unitType) {
    const unitData = UNIT_DATA[unitType];
    if (!unitData) return false;

    // Check if we can place here
    if (!this.gridManager.canPlace(col, row)) return false;

    // Check cost
    if (!this.resourceSystem.canAfford(unitData.base_stats.cost)) return false;

    // Spend Aether
    this.resourceSystem.spendAether(unitData.base_stats.cost);

    // Create unit
    const screenPos = this.gridManager.gridToScreen(col, row);
    const unit = createUnit(unitType, screenPos.x, screenPos.y, unitData);
    unit.gridCol = col;
    unit.gridRow = row;

    this.units.push(unit);
    this.gridManager.markOccupied(col, row);

    // Deselect unit type
    this.selectedUnitType = null;
    this.hud.deselectUnit();

    return true;
  }

  /**
   * Spawn an enemy from wave data
   */
  spawnEnemy(enemyType, pathIndex = 0) {
    const enemyData = ENEMY_DATA[enemyType];
    if (!enemyData) return;

    const path = this.currentStageData.paths[pathIndex] || this.currentStageData.paths[0];
    if (!path || path.length === 0) return;

    const startWaypoint = path[0];
    const screenPos = this.gridManager.gridToScreen(startWaypoint.col, startWaypoint.row);

    const enemy = createEnemy(enemyType, screenPos.x, screenPos.y, enemyData);

    // Convert path waypoints to screen coordinates
    enemy.setPath(path.map(wp => this.gridManager.gridToScreen(wp.col, wp.row)));

    this.enemies.push(enemy);
  }

  /**
   * Fire a projectile from unit to enemy
   */
  fireProjectile(fromX, fromY, target, damage, type = 'arrow', aoeRadius = 0) {
    const proj = this.projectilePool.get();
    proj.init(fromX, fromY, target, damage, type, aoeRadius, this.enemies);
    this.projectiles.push(proj);
  }

  /**
   * Add floating damage text
   */
  addFloatingText(x, y, text, color = '#ff4444', size = 16) {
    this.floatingTexts.push({
      x, y, text, color, size,
      life: 0.8,
      maxLife: 0.8,
    });
  }

  /**
   * Start the next wave
   */
  startWave() {
    if (this.isWaveActive && !this.waveManager.isCurrentWaveComplete()) return;
    this.isWaveActive = true;
    this.waveManager.startNextWave();
    this.hud.onWaveStart();
  }

  _onVictory() {
    this.isWaveActive = false;
    const stars = this._calculateStars();

    // Save progress
    this.playerData.stagesCompleted[this.currentStageId] = {
      completed: true,
      stars: Math.max(stars, this.playerData.stagesCompleted[this.currentStageId]?.stars || 0),
    };
    this.saveManager.save(this.playerData);

    setTimeout(() => this.setState(GameState.RESULT), 1000);
    this._resultData = { victory: true, stars, exp: 500, gold: 300 };
  }

  _onDefeat() {
    this.isWaveActive = false;
    setTimeout(() => this.setState(GameState.RESULT), 1000);
    this._resultData = { victory: false, stars: 0, exp: 100, gold: 50 };
  }

  _calculateStars() {
    const hpPercent = this.coreHP / this.coreMaxHP;
    if (hpPercent >= 0.9) return 3;
    if (hpPercent >= 0.5) return 2;
    return 1;
  }

  _showResultScreen() {
    const data = this._resultData || { victory: false, stars: 0, exp: 0, gold: 0 };
    this.resultScreen.show(data);
    this._showScreen('result-screen');
  }

  /**
   * Pause / Resume
   */
  togglePause() {
    if (this.state === GameState.BATTLE) {
      this.setState(GameState.PAUSE);
      this.gameLoop.pause();
    } else if (this.state === GameState.PAUSE) {
      document.getElementById('pause-overlay').classList.add('hidden');
      this.state = GameState.BATTLE;
      this.gameLoop.resume();
    }
  }

  /**
   * Restart current stage
   */
  restart() {
    document.getElementById('pause-overlay').classList.add('hidden');
    this.gameLoop.resume();
    this._startBattle();
  }

  /**
   * Quit to menu
   */
  quitToMenu() {
    document.getElementById('pause-overlay').classList.add('hidden');
    this.gameLoop.resume();
    this.setState(GameState.MENU);
  }

  // === Screen Management ===
  _showScreen(id) {
    const el = document.getElementById(id);
    if (el) el.classList.add('active');
  }

  _hideScreen(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove('active');
  }

  _delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
