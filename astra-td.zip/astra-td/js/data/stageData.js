/**
 * ASTRA: Aether Guardians — Stage Data
 */
export const STAGE_DATA = {
  stage_1: {
    id: 'stage_1',
    name: 'บทที่ 1: การตื่นรู้',
    description: 'ปกป้องคริสตัลอีเธอร์จากฝูงอสูรโกลาหลที่เข้ามารุกราน',
    corePosition: { col: 5, row: 8 },
    coreHP: 20,
    startingAether: 300,
    tileSize: 64,
    grid: {
      cols: 10,
      rows: 10,
      // 0 = Blocked, 1 = Path, 2 = Placement, 3 = Core
      tiles: [
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 2, 2, 0, 0, 0, 0, 0],
        [0, 1, 1, 1, 2, 2, 0, 0, 0, 0],
        [0, 0, 0, 1, 0, 2, 2, 0, 0, 0],
        [0, 2, 2, 1, 1, 1, 2, 0, 0, 0],
        [0, 2, 2, 0, 0, 1, 2, 2, 0, 0],
        [0, 0, 0, 0, 0, 1, 1, 1, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
        [0, 0, 0, 0, 0, 3, 1, 1, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      ]
    },
    paths: [
      [
        { col: 1, row: 0 }, { col: 1, row: 2 }, { col: 3, row: 2 },
        { col: 3, row: 4 }, { col: 5, row: 4 }, { col: 5, row: 6 },
        { col: 7, row: 6 }, { col: 7, row: 8 }, { col: 5, row: 8 } // Reaches core
      ]
    ],
    waves: [
      {
        groups: [
          { type: 'imp', count: 5, pathIndex: 0, delay: 1.5 }
        ]
      },
      {
        groups: [
          { type: 'imp', count: 8, pathIndex: 0, delay: 1.0 },
          { type: 'rat', count: 3, pathIndex: 0, delay: 0.5 }
        ]
      },
      {
        groups: [
          { type: 'rat', count: 10, pathIndex: 0, delay: 0.3 }
        ]
      },
      {
        groups: [
          { type: 'golem', count: 2, pathIndex: 0, delay: 3.0 },
          { type: 'imp', count: 5, pathIndex: 0, delay: 1.0 }
        ]
      },
      {
        groups: [
          { type: 'boss', count: 1, pathIndex: 0, delay: 0 }
        ]
      }
    ]
  },
  stage_2: {
    id: 'stage_2',
    name: 'บทที่ 2: ทางแยกแห่งชะตากรรม',
    description: 'ศัตรูบุกเข้ามาจากสองเส้นทางพร้อมกัน เตรียมการป้องกันให้ดี!',
    corePosition: { col: 5, row: 8 },
    coreHP: 20,
    startingAether: 350,
    tileSize: 64,
    grid: {
      cols: 10,
      rows: 10,
      tiles: [
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 1],
        [0, 1, 0, 2, 2, 2, 2, 2, 0, 1],
        [0, 1, 0, 2, 0, 0, 0, 2, 0, 1],
        [0, 1, 0, 2, 0, 0, 0, 2, 0, 1],
        [0, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [0, 2, 2, 2, 2, 1, 2, 2, 2, 0],
        [0, 0, 0, 0, 2, 1, 2, 0, 0, 0],
        [0, 0, 0, 0, 2, 1, 2, 0, 0, 0],
        [0, 0, 0, 0, 0, 3, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      ]
    },
    paths: [
      [{ col: 1, row: 0 }, { col: 1, row: 4 }, { col: 5, row: 4 }, { col: 5, row: 8 }],
      [{ col: 9, row: 0 }, { col: 9, row: 4 }, { col: 5, row: 4 }, { col: 5, row: 8 }]
    ],
    waves: [
      { groups: [{ type: 'imp', count: 5, pathIndex: 0, delay: 1.5 }] },
      { groups: [{ type: 'imp', count: 5, pathIndex: 1, delay: 1.5 }] },
      { groups: [{ type: 'imp', count: 4, pathIndex: 0, delay: 1.5 }, { type: 'imp', count: 4, pathIndex: 1, delay: 1.5 }] },
      { groups: [{ type: 'rat', count: 6, pathIndex: 0, delay: 0.8 }, { type: 'rat', count: 6, pathIndex: 1, delay: 0.8 }] },
      { groups: [{ type: 'golem', count: 1, pathIndex: 0, delay: 0 }, { type: 'golem', count: 1, pathIndex: 1, delay: 0 }] },
      { groups: [{ type: 'imp', count: 8, pathIndex: 0, delay: 1.0 }, { type: 'rat', count: 5, pathIndex: 1, delay: 0.5 }] },
      { groups: [{ type: 'rat', count: 5, pathIndex: 0, delay: 0.5 }, { type: 'imp', count: 8, pathIndex: 1, delay: 1.0 }] },
      { groups: [{ type: 'golem', count: 2, pathIndex: 0, delay: 2.0 }, { type: 'golem', count: 2, pathIndex: 1, delay: 2.0 }] },
      { groups: [{ type: 'rat', count: 10, pathIndex: 0, delay: 0.5 }, { type: 'rat', count: 10, pathIndex: 1, delay: 0.5 }] },
      { groups: [{ type: 'boss', count: 1, pathIndex: 0, delay: 0 }, { type: 'boss', count: 1, pathIndex: 1, delay: 0 }] }
    ]
  }
};
